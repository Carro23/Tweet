package src.main.java.com.example.restservice;

public class Tweet {

	private final String usuario;
	private final String texto;
	private final String localizacion;
	private final boolean validacion;

	public Tweet(String usuario, String texto, String localizacion, boolean validacion) {
		this.usuario = usuario;
		this.texto = texto;
		this.localizacion = localizacion;
		this.validacion = validacion;
	}

	public String getUsuario() {
		return usuario;
	}

	public String getTexto() {
		return texto;
	}
	
	public String getLocalizacion() {
		return localizacion;
	}
	
	public boolean getValidacion() {
		return validacion;
	}
	
}
